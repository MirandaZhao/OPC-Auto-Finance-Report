# 提交历史说明

本软件包版本为 **0.3.1**，包内不包含 `.git`，因此不能从本包核对实际 Git 提交历史。

可核对的历史以接收该软件的 Git 仓库中的真实提交为准，包括提交哈希、作者、时间和文件差异。本说明不是提交记录，也不把文件修改时间或文档描述当作 Git 历史。

将文件加入目标仓库并实际提交后，可在仓库的提交页面查看记录，或运行：

```sh
git log --date=iso --format='%h %ad %an %s'
```

如目标仓库已有历史，应保留原有提交，仅记录这次实际发生的变更。

---

# Commit history

This software package is version **0.3.1** and does not include `.git`. Actual Git commit history therefore cannot be verified from this package.

Verifiable history consists of actual commits in the Git repository receiving this software, including commit hashes, authors, timestamps, and file differences. This document is not a commit log and does not treat file modification dates or written descriptions as Git history.

After adding the files to the target repository and making an actual commit, view the repository's commit page or run:

```sh
git log --date=iso --format='%h %ad %an %s'
```

If the target repository already has a history, preserve its existing commits and record only the changes actually made in this update.
